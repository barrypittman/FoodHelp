import { useState, useMemo } from 'react';
import Map from './components/Map';
import Sidebar from './components/Sidebar';
import { resources } from './data';

export default function App() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');

  const filteredResources = useMemo(() => {
    return resources.filter((resource) => {
      const matchesSearch = 
        resource.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resource.address.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesType = filterType === 'all' || resource.type === filterType;
      
      return matchesSearch && matchesType;
    });
  }, [searchQuery, filterType]);

  const handleSelect = (id: string) => {
    setSelectedId(id);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans antialiased">
      <Sidebar
        resources={filteredResources}
        selectedId={selectedId}
        onSelect={handleSelect}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        filterType={filterType}
        setFilterType={setFilterType}
      />
      
      <main className="flex-1 relative">
        <Map
          resources={filteredResources}
          selectedId={selectedId}
          onSelect={handleSelect}
        />
        
        {/* Mobile overlay or additional UI elements could go here */}
        <div className="absolute top-4 right-4 z-[1000] bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg border border-white/20 text-xs font-bold text-slate-700 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Live Resource Map
        </div>
      </main>
    </div>
  );
}
