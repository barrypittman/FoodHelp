/// <reference types="vite/client" />

declare module '*.png' {
  const content: string;
  export default content;
}

declare module 'react-leaflet-cluster' {
  import { FC, ReactNode } from 'react';
  import { MarkerClusterGroupOptions } from 'leaflet';
  
  interface Props extends MarkerClusterGroupOptions {
    children: ReactNode;
    chunkedLoading?: boolean;
  }
  
  const MarkerClusterGroup: FC<Props>;
  export default MarkerClusterGroup;
}
