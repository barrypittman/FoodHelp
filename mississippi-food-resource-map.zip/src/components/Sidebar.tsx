import { FoodResource } from '../data';
import { Search, Phone, MapPin, Filter, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SidebarProps {
  resources: FoodResource[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filterType: string;
  setFilterType: (type: string) => void;
}

export default function Sidebar({
  resources,
  selectedId,
  onSelect,
  searchQuery,
  setSearchQuery,
  filterType,
  setFilterType
}: SidebarProps) {
  const types = ['all', 'pantry', 'box', 'church', 'center'];

  return (
    <div className="w-[400px] h-screen bg-white border-r border-slate-200 flex flex-col shadow-xl z-10 relative">
      <div className="p-6 border-b border-slate-100">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">MS Food Map</h1>
        <p className="text-sm text-slate-500 mt-1 italic">Find local food resources</p>
        
        <div className="mt-6 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name or address..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {types.map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-colors ${
                filterType === type
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto sidebar-scroll p-4 space-y-3">
        <AnimatePresence mode="popLayout">
          {resources.length > 0 ? (
            resources.map((resource) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={resource.id}
                onClick={() => onSelect(resource.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedId === resource.id
                    ? 'bg-emerald-50 border-emerald-200 shadow-sm'
                    : 'bg-white border-slate-100 hover:border-slate-200 hover:shadow-sm'
                }`}
              >
                <div className="flex justify-between items-start">
                  <h3 className={`font-semibold text-sm ${selectedId === resource.id ? 'text-emerald-900' : 'text-slate-900'}`}>
                    {resource.name}
                  </h3>
                  <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                    {resource.type}
                  </span>
                </div>
                
                <div className="mt-3 space-y-2">
                  <div className="flex items-center text-xs text-slate-500">
                    <MapPin className="w-3 h-3 mr-2 text-slate-400" />
                    <span>{resource.address}, {resource.city}</span>
                  </div>
                  <div className="flex items-center text-xs text-slate-500">
                    <Phone className="w-3 h-3 mr-2 text-slate-400" />
                    <span>{resource.phone}</span>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-12">
              <div className="bg-slate-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <Search className="w-6 h-6 text-slate-300" />
              </div>
              <p className="text-sm text-slate-500">No resources found matching your search.</p>
            </div>
          )}
        </AnimatePresence>
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-400 flex justify-between items-center">
        <span>{resources.length} locations found</span>
        <span className="uppercase tracking-widest font-semibold">MS GIS v1.0</span>
      </div>
    </div>
  );
}
