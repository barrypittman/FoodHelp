import { MapContainer, TileLayer, Marker, Popup, useMap, LayersControl } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-cluster';
import L from 'leaflet';
import { FoodResource } from '../data';
import { useEffect } from 'react';

// Fix for default Leaflet icon
import icon from 'leaflet/dist/images/marker-icon.png';
import iconRetina from 'leaflet/dist/images/marker-icon-2x.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: icon,
  iconRetinaUrl: iconRetina,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapProps {
  resources: FoodResource[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

function MapUpdater({ selectedResource }: { selectedResource: FoodResource | null }) {
  const map = useMap();
  
  useEffect(() => {
    if (selectedResource) {
      map.setView([selectedResource.lat, selectedResource.lng], 15, {
        animate: true,
      });
    }
  }, [selectedResource, map]);

  return null;
}

export default function Map({ resources, selectedId, onSelect }: MapProps) {
  const selectedResource = resources.find(r => r.id === selectedId) || null;

  return (
    <div className="w-full h-full relative">
      <MapContainer
        center={[31.25, -89.35]}
        zoom={11}
        scrollWheelZoom={true}
        className="h-full w-full"
      >
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="Google Maps (Roadmap)">
            <TileLayer
              attribution='&copy; Google'
              url="https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Google Maps (Satellite)">
            <TileLayer
              attribution='&copy; Google'
              url="https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="Google Maps (Hybrid)">
            <TileLayer
              attribution='&copy; Google'
              url="https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="OpenStreetMap">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
        </LayersControl>
        
        <MarkerClusterGroup
          chunkedLoading
          maxClusterRadius={50}
        >
          {resources.map((resource) => (
            <Marker
              key={resource.id}
              position={[resource.lat, resource.lng]}
              eventHandlers={{
                click: () => onSelect(resource.id),
              }}
            >
              <Popup>
                <div className="p-1">
                  <h3 className="font-bold text-sm">{resource.name}</h3>
                  <p className="text-xs text-slate-600 mt-1">{resource.address}</p>
                  <p className="text-xs font-medium text-slate-800 mt-1">{resource.phone}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MarkerClusterGroup>

        <MapUpdater selectedResource={selectedResource} />
      </MapContainer>
    </div>
  );
}
