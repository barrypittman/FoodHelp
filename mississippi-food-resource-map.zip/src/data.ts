export interface FoodResource {
  id: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  lat: number;
  lng: number;
  type: 'pantry' | 'box' | 'church' | 'center';
}

export const resources: FoodResource[] = [
  {
    id: '1',
    name: 'Library Food Box',
    phone: 'xxx-xxx-xxxx',
    address: '122 Shelby Speights DR',
    city: 'Purvis',
    lat: 31.1448,
    lng: -89.4095,
    type: 'box'
  },
  {
    id: '2',
    name: 'Pawn Shop Food Box',
    phone: 'xxx-xxx-xxxx',
    address: '103 Main ST',
    city: 'Purvis',
    lat: 31.1441,
    lng: -89.4082,
    type: 'box'
  },
  {
    id: '3',
    name: 'Saint Fabian Catholic Church',
    phone: '601-467-5620',
    address: '9 St. Fabian Way',
    city: 'Hattiesburg',
    lat: 31.3201,
    lng: -89.3804,
    type: 'church'
  },
  {
    id: '4',
    name: 'Developing Family Resources',
    phone: '601-596-6608',
    address: '127 Front ST',
    city: 'Purvis',
    lat: 31.1435,
    lng: -89.4075,
    type: 'center'
  },
  {
    id: '5',
    name: 'Good Hope Baptist Church',
    phone: '601-794-2972',
    address: '331 Purvis-Oloh RD',
    city: 'Purvis',
    lat: 31.1552,
    lng: -89.4151,
    type: 'church'
  },
  {
    id: '6',
    name: 'Edwards Street Fellowship',
    phone: '601-544-6149',
    address: '1910 Edward ST',
    city: 'Hattiesburg',
    lat: 31.3155,
    lng: -89.2852,
    type: 'pantry'
  },
  {
    id: '7',
    name: 'Fieldhouse For Homeless',
    phone: '601-602-1804',
    address: '5712 US HWY 49',
    city: 'Hattiesburg',
    lat: 31.3602,
    lng: -89.3301,
    type: 'center'
  }
];
